export class TransactionDetails{
    fromAcc:number;
    toAcc:number;
    amt:number;
}