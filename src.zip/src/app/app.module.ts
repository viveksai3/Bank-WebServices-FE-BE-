import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { HomeComponent } from './home/home.component';
import { RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { DepositComponent } from './deposit/deposit.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { FundtransferComponent } from './fundtransfer/fundtransfer.component';
import { FirstComponent } from './first/first.component';
import { CrudComponent } from './crud/crud.component';
import { EmptyComponent } from './empty/empty.component';
import { AdminComponent } from './admin/admin.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { NavbarComponent } from './navbar/navbar.component';
import {CookieService} from 'ngx-cookie-service'
import { AuthGuard } from './auth.guard';
@NgModule({
  declarations: [
    AppComponent,
    FirstComponent,
    HomeComponent,
    LoginComponent,
    DepositComponent,
    WithdrawComponent,
    FundtransferComponent,
    CrudComponent,
    EmptyComponent,
    AdminComponent,
    AdminloginComponent,
    NavbarComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule, 
 RouterModule.forRoot([
      {path: 'home', component: HomeComponent},
      {path: 'first', component: FirstComponent},
      {path: 'deposit', component: DepositComponent,canActivate:[AuthGuard]},
      {path: 'withdraw', component: WithdrawComponent,canActivate:[AuthGuard]},
      {path: 'fundtransfer', component: FundtransferComponent,canActivate:[AuthGuard]},
      {path: 'login', component: LoginComponent},
      {path: 'crud', component: CrudComponent,canActivate:[AuthGuard]},
      {path: 'empty', component:EmptyComponent},
      {path: 'admin', component: AdminComponent,canActivate:[AuthGuard]},
      {path: 'adminlogin', component:AdminloginComponent},
      {path: 'navbar', component:NavbarComponent}


    ]) ,
    FormsModule,
    HttpClientModule
  ],
  providers: [CookieService],
  bootstrap: [AppComponent]
})
export class AppModule { }
