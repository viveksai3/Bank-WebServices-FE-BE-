import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { HomeComponent } from './home/home.component';
import { RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { DepositComponent } from './deposit/deposit.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { FundtransferComponent } from './fundtransfer/fundtransfer.component';
import { FirstComponent } from './first/first.component';
import { ShowbalanceComponent } from './showbalance/showbalance.component';

@NgModule({
  declarations: [
    AppComponent,
    FirstComponent,
    HomeComponent,
    LoginComponent,
    DepositComponent,
    WithdrawComponent,
    FundtransferComponent,
    ShowbalanceComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule, 
 RouterModule.forRoot([
      {path: 'home', component: HomeComponent},
      {path: 'first', component: FirstComponent},
      {path: 'deposit', component: DepositComponent},
      {path: 'withdraw', component: WithdrawComponent},
      {path: 'fundtransfer', component: FundtransferComponent},
      {path: 'login', component: LoginComponent},
      {path: 'showbalance', component: ShowbalanceComponent},





    ]) ,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
