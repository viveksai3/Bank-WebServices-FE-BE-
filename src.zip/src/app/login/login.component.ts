import { Component, OnInit } from '@angular/core';
import { BankService } from '../bank.service';
import { CustomerDetails } from '../CustomerDetails';
import {Router} from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private bankservice:BankService,private router:Router) { }

  login:CustomerDetails={
    accountNo:0,
    firstName: '',
    lastName: '',
    emailId: '',
    password:'',
    pancardNo:null,
    aadharNo: '',
    address: '',
    mobileNo: '',
    balance:null,
    depositAmount:0

  };
  
  userlogin():void{
    let accno:number
    this.bankservice.login(this.login).subscribe( data => {
      
      if(data.accountNo!=0)
      {
        alert("Login success/n your account number is: "+data);
        console.log("login:"+ data);
       this.router.navigateByUrl('/deposit');
      }
     
    });

  }

  ngOnInit() {
  }

}
