import { Component, OnInit } from '@angular/core';
import { BankService } from '../bank.service';
import { CustomerDetails } from '../CustomerDetails';
import {Router} from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private bankservice:BankService,private router:Router) { }

  login:CustomerDetails={
    accountNo:null,
    firstName: '',
    lastName: '',
    emailId: '',
    password:'',
    pancardNo:null,
    aadharNo: '',
    address: '',
    mobileNo: '',
    balance:null,
    depositAmount:0

  };
  userlogin():void{
    let accno:number
    this.bankservice.login(this.login).subscribe( resp => {
      
      if(resp != 0)
      {
        console.log("login:"+resp);
        alert("login successful")
       this.router.navigateByUrl('/crud');
      }
      else{
        alert("Enter valid details")
      }
     
    },
    error => alert("Invalid login credentials!!"+"\n"+"Re-enter"));

  }

  ngOnInit() {
  }

}
