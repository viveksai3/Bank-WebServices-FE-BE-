import { Component, OnInit } from '@angular/core';
import { BankService } from '../bank.service';
import { CustomerDetails } from '../CustomerDetails';
import {Router} from '@angular/router';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private bankservice:BankService,private router:Router,private cookie:CookieService) { }
  account:any;
  login:CustomerDetails={
    accountNo:null,
    firstName: '',
    lastName: '',
    emailId: '',
    password:'',
    pancardNo:null,
    aadharNo: '',
    address: '',
    mobileNo: '',
    balance:null,
    depositAmount:0

  };
  number:any;
  userlogin():void{
   
    this.bankservice.login(this.login).subscribe( resp => {
      if(resp != 0)
      {
        console.log("login:"+resp);
        alert("login successful")
       
        // setting up cookie values[generally cookie from Cookieservice]
        this.cookie.set("accountNo",this.login.accountNo.toString());
        this.cookie.set("password",this.login.password.toString());
        
       this.router.navigateByUrl('/crud');
      }
      else{
        alert("Enter valid details")
      }
     
    },
    error => alert("Invalid login credentials!!"+"\n"+"Re-enter"));

  }

  ngOnInit() {
    
  }

}
