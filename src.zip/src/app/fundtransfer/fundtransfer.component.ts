import { Component, OnInit } from '@angular/core';
import { TransactionDetails } from '../Transactiondetails';
import { BankService } from '../bank.service';

@Component({
  selector: 'app-fundtransfer',
  templateUrl: './fundtransfer.component.html',
  styleUrls: ['./fundtransfer.component.css']
})
export class FundtransferComponent implements OnInit {

  transfer:TransactionDetails={
    fromAcc:0,
    toAcc:0,
    amt:0
  };
  constructor(private service:BankService) { }
  fundtransfer():void
  {
    this.service.transfer(this.transfer).subscribe(res=>
      {
        alert("TRANSACTION SUCCESSFUL")
      })
  }
  ngOnInit() {
  }

}
