import { Component, OnInit } from '@angular/core';
import { TransactionDetails } from '../Transactiondetails';
import { BankService } from '../bank.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-fundtransfer',
  templateUrl: './fundtransfer.component.html',
  styleUrls: ['./fundtransfer.component.css']
})
export class FundtransferComponent implements OnInit {
  //number is assigned with acc from service 
  number:any

  transfer:TransactionDetails={
    fromAcc:this.number,
    toAcc:null,
    amt:null
  };

  constructor(private service:BankService,private router:Router) { }

  fundtransfer():void
  {
    this.service.transfer(this.transfer).subscribe(res=>
      {
        alert("TRANSACTION SUCCESSFUL"+"\n"+"Transaction Id :"+res)
        console.log(res)
        this.router.navigateByUrl('/crud');

      },
      err=>
      {
        alert("Insufficient funds/ToAccount number doesnot exist!")
      })
  }
  
  ngOnInit() {
    //getting the value of acc from service
    this.service.acc.subscribe(res=>
      {
        this.number=res
      })
  }

}
