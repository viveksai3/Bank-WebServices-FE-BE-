import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CustomerDetails } from './CustomerDetails';
import { Observable } from 'rxjs';
import { TransactionDetails } from './Transactiondetails';

@Injectable({
  providedIn: 'root'
})
export class BankService {

  constructor(private http:HttpClient) {}
  private  url="http://localhost:8082/bank/register";
  private  url1="http://localhost:8082/bank/login";
  private  url2="http://localhost:8082/bank/deposit";
  private  url3="http://localhost:8082/bank/withdraw";
  private  url4="http://localhost:8082/bank/fundtransfer";
  private  url5="http://localhost:8082/bank/showbalance";


  public register(user) {
    return this.http.post<CustomerDetails>(this.url, user);
  }

  public login(login): Observable<CustomerDetails>
  {
    return this.http.post<CustomerDetails>(this.url1, login);

  }

  public deposit(deposit)
  {
    return this.http.put<number>(this.url2,deposit);
  }

  public withdraw(withdraw)
  {
    return this.http.put<number>(this.url3,withdraw);

  }

  public transfer(transfer)
  {
    return this.http.put<TransactionDetails>(this.url4,transfer);

  }
  
  public showbalance()
  {
    return this.http.get<number>(this.url5);
  }
}
