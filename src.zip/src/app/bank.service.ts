import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CustomerDetails } from './CustomerDetails';
import { Observable, observable, BehaviorSubject } from 'rxjs';
import { TransactionDetails } from './Transactiondetails';

@Injectable({
  providedIn: 'root'
})
export class BankService {

  constructor(private http:HttpClient) {}
  private  baseurl="http://localhost:8082/bank";
  isLogg:boolean=false;

  //here acc holds the return type of login() and can be used any where by subscribing
  acc:Observable<CustomerDetails>;

  public isLog(log):any
  {
    this.isLogg=log;
    console.log("hello"+this.isLogg)

  }

  
  public register(user) {
    
    return this.http.post<CustomerDetails>(this.baseurl+"/register", user);
  }

  public login(login): Observable<any>
  {
   
    this.acc=this.http.post<CustomerDetails>(this.baseurl+"/login", login);
    return this.acc;

  }

  public deposit(deposit)
  {
    return this.http.put<number>(this.baseurl+"/deposit",deposit);
  }

  public withdraw(withdraw)
  {
    return this.http.put<number>(this.baseurl+"/withdraw",withdraw);

  }

  public transfer(transfer)
  {
    return this.http.put<TransactionDetails>(this.baseurl+"/fundtransfer",transfer);

  }
  
  public showbalance()
  {
    return this.http.get<number>(this.baseurl+"/showbalance");
  }

  public getAllData(): Observable<any>
  {
    return this.http.get(this.baseurl+"/admingetAll");
  }

  public deleteData(id)
  {

    return this.http.delete<CustomerDetails>(this.baseurl+ "/delete/" + id);
  }
}
