import { Component, OnInit, Input } from '@angular/core';
import { CustomerDetails } from '../CustomerDetails';
import { HttpClient } from '@angular/common/http';
import { BankService } from '../bank.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-first',
  templateUrl: './first.component.html',
  styleUrls: ['./first.component.css']
})
export class FirstComponent implements OnInit {
   

  constructor(private http:HttpClient,private bankService:BankService,private router:Router) { }

  ngOnInit() {
  }
 
  personalInformation:CustomerDetails={
    accountNo:0,
    firstName: '',
    lastName: '',
    emailId: '',
    password:'',
    pancardNo:null,
    aadharNo: '',
    address: '',
    mobileNo: '',
    balance:null,
    depositAmount:0

  };
  submitted = false;
  balance : number
  url : string;
  regex:string= "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
account:number;
confirmPassword:string
  onSubmit():void{
  // this.url="http://localhost:8082/bank/showbalance";

  //   this.submitted = true;
  //   alert(this.personalInformation.firstName);
     console.log(this.personalInformation);
     
  //   this.http.get<number>(this.url).subscribe(
  //     res=>{
  //       console.log(res);
  //       this.balance=res
  //     },
  //     error=>{
  //       console.log("error")
  //     }
  //   )
  
  if((this.personalInformation.aadharNo=="") || (this.personalInformation.pancardNo==null)) 
  {
    alert("enter all fields")
  }
  else if(this.personalInformation.mobileNo.length!=10)
  {
    alert("Enter valid mobile number")

  }
  else if(!(this.personalInformation.emailId.match(this.regex)))
  {
    alert("enter valid email address")
  }
  else if(!(this.personalInformation.password==this.confirmPassword))
  {
    alert("passwords didnot match"+"\n"+"Re-enter")
  }
  else{
    this.bankService.register(this.personalInformation).subscribe( data => {
      alert("User created successfully.\n your account number is : "+data);
      this.router.navigateByUrl("/login");
  
    });
}
  }

   getCurrentModel() { 
    return JSON.stringify(this.personalInformation); 
  }


}
