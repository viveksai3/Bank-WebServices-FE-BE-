import { Component, OnInit } from '@angular/core';
import { CustomerDetails } from '../CustomerDetails';
import { HttpClient } from '@angular/common/http';
import { BankService } from '../bank.service';

@Component({
  selector: 'app-first',
  templateUrl: './first.component.html',
  styleUrls: ['./first.component.css']
})
export class FirstComponent implements OnInit {
  constructor(private http:HttpClient,private bankService:BankService) { }

  ngOnInit() {
  }
  personalInformation:CustomerDetails={
    accountNo:0,
    firstName: '',
    lastName: '',
    emailId: '',
    password:'',
    pancardNo:null,
    aadharNo: '',
    address: '',
    mobileNo: '',
    balance:null,
    depositAmount:0

  };
  submitted = false;
  balance : number
  url : string;

  onSubmit():void{
  // this.url="http://localhost:8082/bank/showbalance";

  //   this.submitted = true;
  //   alert(this.personalInformation.firstName);
     console.log(this.personalInformation);
  //   this.http.get<number>(this.url).subscribe(
  //     res=>{
  //       console.log(res);
  //       this.balance=res
  //     },
  //     error=>{
  //       console.log("error")
  //     }
  //   )
  this.bankService.register(this.personalInformation).subscribe( data => {
    alert("User created successfully.\n your account number is : "+data);
  });
   
  
  }

   getCurrentModel() { 
    return JSON.stringify(this.personalInformation); 
  }


}
