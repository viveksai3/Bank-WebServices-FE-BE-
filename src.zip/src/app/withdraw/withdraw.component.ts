import { Component, OnInit } from '@angular/core';
import { BankService } from '../bank.service';

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {

  constructor(private servie:BankService) { }

  amount:number;
  withdraw()
  {
    this.servie.withdraw(this.amount).subscribe(data =>
      {
        alert("amount withdrawn: "+this.amount+"\n"+"remaining account balance :"+data)
        console.log(data)
      }
      
    )
  }
  ngOnInit() {
  }

}
