import { Component, OnInit } from '@angular/core';
import { BankService } from '../bank.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {

  constructor(private servie:BankService,private router:Router) { }

  amount:number;
  withdraw()
  {
    if(this.amount>0)
    {
    this.servie.withdraw(this.amount).subscribe(data =>
      {
        if(data!=0)
        {
        alert("amount withdrawn: "+this.amount+"\n"+"remaining account balance :"+data)
        console.log(data)
        this.router.navigateByUrl('/crud');
        }
        else{
          alert("Insufficient Funds")
        }
      }
      
    )
    }
    else{
      alert("invalid amount")
    }
  }
  ngOnInit() {
  }

}
