export class CustomerDetails{
    accountNo:0;
    firstName: string ;
    lastName: string ;
    emailId: string ;
    password: string ;
    pancardNo: number ;
    aadharNo: string ;
    address: string ;
    mobileNo: string ;
    balance:number;
    depositAmount:number;
    
  }