import { Component, OnInit } from '@angular/core';
import { BankService } from '../bank.service';
import { CustomerDetails } from '../CustomerDetails';
import { Router, Routes } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {

  personalInformation:CustomerDetails={
    accountNo:0,
    firstName: '',
    lastName: '',
    emailId: '',
    password:'',
    pancardNo:null,
    aadharNo: '',
    address: '',
    mobileNo: '',
    balance:null,
    depositAmount:0

  };

  amount:number;
  constructor(private bankService:BankService,private router:Router,private cookie:CookieService) { }

  deposit():void{
    if(this.amount>0)
    {
    this.bankService.deposit(this.amount).subscribe(data =>
      {
        console.log(data);
        alert("deposited amount: "+this.amount+"\n"+"account balance: "+data)
        this.router.navigateByUrl('/crud');
      })
    }
    else{
      alert("invalid amount")
    }
  }

  logout()
  {
    // here deleting the cookie values coz 
    // when we directly hit the withdraw url without logging in again it will trigger the login component
    //this cookie availability is checked in AUTHGUARD
    this.cookie.delete("accountNo");
    this.cookie.delete("password");
    this.router.navigateByUrl("/")
  }
  ngOnInit() {
  }

}
