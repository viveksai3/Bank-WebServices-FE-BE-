import { Component, OnInit } from '@angular/core';
import { BankService } from '../bank.service';
import { CustomerDetails } from '../CustomerDetails';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {

  personalInformation:CustomerDetails={
    accountNo:0,
    firstName: '',
    lastName: '',
    emailId: '',
    password:'',
    pancardNo:null,
    aadharNo: '',
    address: '',
    mobileNo: '',
    balance:null,
    depositAmount:0

  };

  amount:number;
  constructor(private bankService:BankService) { }

  deposit():void{
    this.bankService.deposit(this.amount).subscribe(data =>
      {
        console.log(data);
        alert("deposited amount: "+this.amount+"\n"+"account balance: "+data)
      })
  }

  ngOnInit() {
  }

}
