import { Component, OnInit } from '@angular/core';
import { Routes, Router } from '@angular/router';
import { BankService } from '../bank.service';

@Component({
  selector: 'app-crud',
  templateUrl: './crud.component.html',
  styleUrls: ['./crud.component.css']
})
export class CrudComponent implements OnInit {

  constructor(private router:Router,private service:BankService) { }

  deposit()
  {
    this.router.navigateByUrl("/deposit")
  }

  withdraw()
  {
    this.router.navigateByUrl("/withdraw")

  }

  fund()
  {
    this.router.navigateByUrl("/fundtransfer")
  }

  showbalance():void{
    this.service.showbalance().subscribe(res=>
      {
        alert("balance is :"+res)
      });
  }
  ngOnInit() {
  }

}
