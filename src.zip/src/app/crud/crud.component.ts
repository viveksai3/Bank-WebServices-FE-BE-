import { Component, OnInit } from '@angular/core';
import { Routes, Router } from '@angular/router';
import { BankService } from '../bank.service';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-crud',
  templateUrl: './crud.component.html',
  styleUrls: ['./crud.component.css']
})
export class CrudComponent implements OnInit {
  isLoggedIn:boolean=false
  constructor(private router:Router,private service:BankService,private cookie:CookieService) { }

  deposit()
  {
    this.router.navigateByUrl("/deposit")
  }

  withdraw()
  {
    this.router.navigateByUrl("/withdraw")

  }

  fund()
  {
    
    this.router.navigateByUrl("/fundtransfer")
  }

  logout():void{
    //deleting cookies
    this.cookie.delete("accountNo");
    this.cookie.delete("password");
    this.router.navigateByUrl('/empty')
  }
  showbalance():void{
    this.service.showbalance().subscribe(res=>
      {
        alert("balance is :"+res)
      });
  }
  ngOnInit() {
    this.isLoggedIn=true
    this.service.isLog(this.isLoggedIn)
  }

}
