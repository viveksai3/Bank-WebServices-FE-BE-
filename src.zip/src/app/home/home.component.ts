import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { BankService } from '../bank.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private router:Router,private service:BankService) { }

  isLoggedIn:boolean=this.service.isLogg;
  register()
  {
    this.router.navigateByUrl("/first")
  }


  login()
  {
    this.router.navigateByUrl("/login")
  }

  adminLogin()
  {
    this.router.navigateByUrl("/adminlogin")
  }
  ngOnInit() {
    console.log("hi"+this.isLoggedIn)
  }

}
