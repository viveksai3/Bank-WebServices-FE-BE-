import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerDetails } from '../CustomerDetails';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent implements OnInit {
  id:string;
  password:string;
  constructor(private router:Router) { }

  onSubmit():void
  {
    if(this.id==this.password)
    {
      this.router.navigateByUrl("/admin")
    }
    else
    {
      alert("invalid credentials")
    }
  } 
   ngOnInit() {
  }

 
  
}
