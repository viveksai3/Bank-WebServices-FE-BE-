import { Component, OnInit } from '@angular/core';
import { BankService } from '../bank.service';
import { Router } from '@angular/router';
import { CustomerDetails } from '../CustomerDetails';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  constructor(private service:BankService,private router:Router) { }

  personalInformation:CustomerDetails={
    accountNo:0,
    firstName: '',
    lastName: '',
    emailId: '',
    password:'',
    pancardNo:null,
    aadharNo: '',
    address: '',
    mobileNo: '',
    balance:null,
    depositAmount:0

  };
  
  //getting the custoemr data
  logout()
  {
    this.router.navigateByUrl("/empty")
  }
  delete(accNo):void{
    this.service.deleteData(accNo).subscribe(res=>
      {
        console.log(res)
        this.ngOnInit()
      }),
      err=>
      {
        console.log(err)
      }
  }
  ngOnInit() {
    this.service.getAllData().subscribe(res=>
      {
        this.personalInformation = res
        console.log(res)
        
      });
      
  }
  id: any;
  onSubmit(){
    this.id = this.personalInformation.accountNo;
    
  }

  isSearched:boolean=false

  searched()
  {
    this.isSearched=true
  }
  goToBottom(){
    window.scrollTo(0,document.body.scrollHeight);

  }
  goToTop()
  {
    window.scrollTo(0,0);
  }

}
