import { Component, OnInit } from '@angular/core';
import { BankService } from '../bank.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  constructor(private service:BankService) { }

  submit()
  {
    this.service.getAllData().subscribe(res=>
      {
        console.log(res)
      });
  }
  ngOnInit() {
  }

}
