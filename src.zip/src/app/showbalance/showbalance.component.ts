import { Component, OnInit } from '@angular/core';
import { BankService } from '../bank.service';

@Component({
  selector: 'app-showbalance',
  templateUrl: './showbalance.component.html',
  styleUrls: ['./showbalance.component.css']
})
export class ShowbalanceComponent implements OnInit {

  constructor(private service:BankService) { }

  showbalance():void{
    this.service.showbalance().subscribe(res=>
      {
        alert("balance is :"+res)
      });
  }
  ngOnInit() {
  }
}
